package heranca;

/**
 *
 * @author andrea
 */
public class Heranca {

    public static void main(String[] args) {
        Estudante e = new Estudante();
        e.setNome("Jose");
        e.setCurso("Direito");
        e.mostra();
    }
}
