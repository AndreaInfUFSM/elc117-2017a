package arraylist_demo;

class VeiculoApp {

   public static void main(String args[]) {
      Veiculo v = new Veiculo("ELC1170", "Vermelho", "Renault", "Clio", 2013, 23000.0f);
      System.out.printf("Marca: %s, Modelo: %s, Ano: %d, Cor: %s, Placa: %s, Valor: %.2f\n",
         v.getMarca(), v.getModelo(), v.getAno(), v.getCor(), v.getPlaca(), v.getValor());
   }
}
