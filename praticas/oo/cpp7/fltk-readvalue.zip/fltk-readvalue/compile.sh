g++ -std=c++11 main.cpp window.cxx -lfltk -pthread
